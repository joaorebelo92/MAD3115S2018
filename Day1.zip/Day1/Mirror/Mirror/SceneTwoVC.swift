//
//  SceneTwoVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-03.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SceneTwoVC: UIViewController {

    var alreadyEnteredName : Bool = false
    var alreadyEnteredAge : Bool = false
    var alreadyEnteredTest : Bool = false
    var alreadyEnteredTestDate : Bool = false
    
    @IBOutlet var lblFullName: UILabel!
    @IBAction func txtFullName(_ sender: UITextField) {
        if !alreadyEnteredName {
            pvStatus.progress += 0.3
            print("test")
            alreadyEnteredName = true
        }
    }
    
    @IBOutlet var lblAge: UILabel!
    @IBAction func sldAge(_ sender: UISlider) {
        lblShowAge.isHidden = false
        lblShowAge.text = "\(sender.value) years old."
        if !alreadyEnteredAge {
            pvStatus.progress += 0.2
            alreadyEnteredAge = true
        }
        
    }
    @IBOutlet var lblShowAge: UILabel!
    @IBOutlet var lblTest: UILabel!
    @IBAction func smcTest(_ sender: UISegmentedControl) {
        if !alreadyEnteredTest {
            pvStatus.progress += 0.2
            alreadyEnteredTest = true
        }
    }
    @IBAction func dtpDate(_ sender: UIDatePicker) {
        if !alreadyEnteredTestDate {
            pvStatus.progress += 0.2
            alreadyEnteredTestDate = true
        }
    }
    @IBOutlet var pvStatus: UIProgressView!
    @IBAction func btnSubmit(_ sender: UIButton) {
        if alreadyEnteredName && alreadyEnteredAge && alreadyEnteredTest && alreadyEnteredTestDate{
            let nameAlert = UIAlertController(title: "Submited", message: "Form Submitted.", preferredStyle: .alert)
            nameAlert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
            self.present(nameAlert, animated: true)
        }else{
            let nameAlert = UIAlertController(title: "Values Missing", message: "Can't submit with empty fields.", preferredStyle: .actionSheet)
            nameAlert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
            self.present(nameAlert, animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblShowAge.isHidden = true
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
