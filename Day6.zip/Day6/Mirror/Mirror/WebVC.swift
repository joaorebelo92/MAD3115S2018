//
//  WebVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import WebKit

//private let reuseIdentifier = "Cell"

class WebVC: UIViewController {
    @IBOutlet weak var myWebView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //myWebView.load(URLRequest(url: URL(string: "https://www.google.ca/")!))
        myWebView.load(URLRequest(url: Bundle.main.url(forResource: "mypage", withExtension: "html")!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
