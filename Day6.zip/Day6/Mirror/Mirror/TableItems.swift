//
//  TableItems.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class TableItems{
    static var titles : [String] = ["Audio", "Video", "Web View", "Calendar", "Location", "Contacts", "Plist"]
    static var subTitles : [String] = ["Hear it clear", "Watch it better", "World is yours", "Time is not yours", "Be everywhere", "Stay Connected", "Property List"]
    static var images : [String] = ["audio", "video", "web", "calendar", "location", "contacts", "Plist"]
    
}
