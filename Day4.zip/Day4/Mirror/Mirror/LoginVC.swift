//
//  LoginVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-07.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    @IBOutlet var switchRemember: UISwitch!
    
    
    @IBAction func btnSignIn(_ sender: UIButton) {
        if validateUser(){
            
            if switchRemember.isOn{
                //save Data
                UserDefaults.standard.set(txtEmail.text, forKey: "email")
                UserDefaults.standard.set(txtPassword.text, forKey: "password")
                UserDefaults.standard.set(switchRemember.isOn, forKey: "rememberme")
                
            }else{
                //remove Data
                if UserDefaults.standard.string(forKey: "email") != nil{
                    UserDefaults.standard.removeObject(forKey: "email")
                }
                
                if UserDefaults.standard.value(forKey: "password") != nil {
                    UserDefaults.standard.removeObject(forKey: "password")
                }
                
                UserDefaults.standard.set(switchRemember.isOn, forKey: "rememberme")
            }
            
            let mainSB : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = mainSB.instantiateViewController(withIdentifier: "HomeScene")
            //self.present(homeVC, animated: true, completion: nil)
            navigationController?.pushViewController(homeVC, animated: true)
        }else{
            let infoAlert = UIAlertController(title: "Invalid User", message: "Incorrect Username and/or Password", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Retry", style: .default, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
    }
    @IBAction func btnSignUp(_ sender: UIButton) {
        let mainSb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let signUpVC = mainSb.instantiateViewController(withIdentifier: "SignUpScene")
        navigationController?.pushViewController(signUpVC, animated: true)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let email = UserDefaults.standard.string(forKey: "email"){
            txtEmail.text = email
        }
        
        if let password = UserDefaults.standard.value(forKey: "password") {
            txtPassword.text = password as? String
        }
        
        let switchR = UserDefaults.standard.bool(forKey: "rememberme")
        self.switchRemember.setOn(switchR, animated: true)
      
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func validateUser() -> Bool {
        if txtEmail.text == "test" && txtPassword.text == "test"{
            return true
        }else{
            return false
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
